<<<<<<< HEAD
# mava-project
this is an open source project/management collaboration tool which mainly focused on building a bridge between technical and non-technical members of a project
=======
mava
====

A Symfony project created on January 28, 2016, 12:27 pm.
>>>>>>> release/0.1.1
